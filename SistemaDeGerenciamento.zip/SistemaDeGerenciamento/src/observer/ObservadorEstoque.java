package observer;

public interface ObservadorEstoque {
    void atualizar(String mensagem);
}
