package adapter;

public class ApiLegadaRastreamento {
    public void localizar(String id) {
        System.out.println("Pacote " + id + " localizado pela API legada.");
    }
}
