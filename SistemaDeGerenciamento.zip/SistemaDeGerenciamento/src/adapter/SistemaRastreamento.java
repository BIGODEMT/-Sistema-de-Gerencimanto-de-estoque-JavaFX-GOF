package adapter;

public interface SistemaRastreamento {
    void rastrearPacote(String idPacote);
}
